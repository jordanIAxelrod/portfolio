var menu = document.querySelector('.hamburger');
var main = document.querySelector('main')


menu.addEventListener('click', function(e) {
  main.classList.toggle('open');
  menu.classList.toggle('change');
  e.stopPropagation();
});
nav.addEventListener('click', function(e) {
  nav.classList.toggle('open');
  menu.classList.toggle('change');
  e.stopPropagation();
});
